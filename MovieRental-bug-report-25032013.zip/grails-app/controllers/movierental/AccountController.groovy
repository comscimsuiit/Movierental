package movierental

class AccountController {

	def scaffold = true;

    //def index() { }
}
